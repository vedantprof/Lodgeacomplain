package com.example.vedant.lodgeacomplain;

public class Wardwisecomplain  {
    private String cname;
    int cid;
    int wid;
    private byte[] image;
    private String description;

    public Wardwisecomplain(String Cname,int Cid,int Wid,byte[] image1,String description1){
        cname=Cname;
        cid=Cid;
        wid=Wid;
        image=image1;
        description=description1;
    }
    public String getname(){return cname;}
    public int getid(){return cid;}
    public int getWid(){return wid;}
    public byte[] getimage(){return image;}
    public String getdescription(){return description;}
}
