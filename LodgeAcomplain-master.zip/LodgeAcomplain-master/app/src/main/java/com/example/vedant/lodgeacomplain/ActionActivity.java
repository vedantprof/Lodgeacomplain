package com.example.vedant.lodgeacomplain;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class ActionActivity extends AppCompatActivity {
    TextView t1,t2,t3;
    ImageView iv4;
    EditText et1;
    Button btn;
    DbHepler obj;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_action);
        obj=new DbHepler(this);
        btn=findViewById(R.id.enteraction);
        t1 = (TextView)findViewById(R.id.textView5);
        et1=findViewById(R.id.action);
        t3 = (TextView)findViewById(R.id.textView6);
        iv4=findViewById(R.id.imageView4);

        String n1 = getIntent().getStringExtra("a1");
        String n2 = getIntent().getStringExtra("a2");
        final int id=Integer.parseInt(n1);
        Cursor c=obj.getcompid(id);
        c.moveToFirst();
        byte[] image=c.getBlob(c.getColumnIndex("Cimg"));
        String desc=c.getString(c.getColumnIndex("Cdesc"));
        t1.setText(n2);
        t3.setText(desc);
        if (image!=null){
            iv4.setImageBitmap(BitmapFactory.decodeByteArray(image,0,image.length));
        }
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    int CID = id;
                    String cstatus = "Complete";
                    String caction = et1.getText().toString();

                 //   showmsg("cid"+id+""+cstatus+""+caction);

                    if(obj.updatecomplain(CID,cstatus,caction))
                    {
                        Toast.makeText(ActionActivity.this, "Updated", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(getApplicationContext(),WardNavigationActivity.class);
                        startActivity(i);
                        finish();
                    }
                    else
                    {
                        Toast.makeText(ActionActivity.this, "Not Update Your Complain", Toast.LENGTH_SHORT).show();
                    }


            }
        });
    }

    public void showmsg(String msg)
    {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
