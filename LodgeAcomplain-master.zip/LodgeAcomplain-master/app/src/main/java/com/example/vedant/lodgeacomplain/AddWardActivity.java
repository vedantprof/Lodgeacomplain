package com.example.vedant.lodgeacomplain;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class AddWardActivity extends AppCompatActivity {
    Spinner zone;
    TextView selectzone;
    EditText wemail,wpwd,wno;
    Button addw,disw;
    DbHepler obj;
    ArrayList<String> list,list1;
    int id1;
    String w;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_ward);

        obj = new DbHepler(this);
        startconfig();
        zone();

        zone.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String w = list1.get(position);
                id1 = Integer.parseInt(w);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        addw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Wno = wno.getText().toString();
                String Wemail = wemail.getText().toString();
                String Wpwd = wpwd.getText().toString();

                try
                {
                    if(obj.addward(id1,Wno,Wemail,Wpwd))
                    {
                        showmessage("Sign up Successfully!!");
                        clrtext();
                    }
                    else
                    {
                        showmessage("Failed!!");
                    }
                }
                catch (Exception e)
                {
                    showmessage(e.toString());
                }
            }
        });

        disw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(getApplicationContext(),disward.class);
                startActivity(a);
            }
        });
    }

    public void startconfig()
    {
        zone = (Spinner)findViewById(R.id.zone);
        wno = (EditText)findViewById(R.id.t1);
        wemail = (EditText)findViewById(R.id.wemail);
        wpwd = (EditText)findViewById(R.id.wpwd);
        addw = (Button)findViewById(R.id.addw);
        disw = (Button)findViewById(R.id.disw);
    }

    public void showmessage(String msg)
    {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    public void clrtext()
    {
        wno.setText("");
        wemail.setText("");
        wpwd.setText("");
    }

    public void zone()
    {
        list = new ArrayList<String>();
        list1 = new ArrayList<String>();
        Cursor c = obj.getzones();

        final int Zname = c.getColumnIndex("Zname");
        final int Zid= c.getColumnIndex("Zid");
        while(c.moveToNext())
        {
            list.add(c.getString(Zname));
            list1.add(c.getString(Zid));
        }

        ArrayAdapter arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_spinner_item,list);
        zone.setAdapter(arrayAdapter);
    }

//    public void ward()
//    {
//        list1 = new ArrayList<>();
//        Cursor c1 = obj.getallwards();
//
//        int Wno = c1.getColumnIndex("Wno");
//        while(c1.moveToNext())
//        {
//            list1.add(c1.getString(Wno));
//        }
//
//        ArrayAdapter arrayAdapter=new ArrayAdapter(getApplicationContext(),android.R.layout.simple_spinner_item, list1);
//        wno.setAdapter(arrayAdapter);
//    }

//    public void wardbind(int id1)
//    {
//        list2 = new ArrayList<String>();
//        list3 = new ArrayList<>();
//        list4= new ArrayList<String>();
//        Cursor c2 = obj.getwards(id1);
//
//        int Wid = c2.getColumnIndex("Wid");
//        int Zid = c2.getColumnIndex("Zid");
//        int Wno = c2.getColumnIndex("Wno");
//        while(c2.moveToNext())
//        {
//            list2.add(c2.getString(Wno));
//            list3.add(c2.getString(Zid));
//        }
//
//        ArrayAdapter arrayAdapter=new ArrayAdapter(getApplicationContext(),android.R.layout.simple_spinner_item, list2);
//        wno.setAdapter(arrayAdapter);
//    }
}