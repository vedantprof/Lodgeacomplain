package com.example.vedant.lodgeacomplain;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;

public class DisplayDeptActivity extends AppCompatActivity {
    ListView disdpt;
    ArrayList list,list1,list2,list3;
    DbHepler obj;
    SharedPreferences sharedPreferences;

    public static final String Mypreferences="MyLogin";
    public  static final String WordID="wordkey";
    String wid="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_dept);
        
        disdpt=(ListView)findViewById(R.id.disdpt);
        obj=new DbHepler(this);
        sharedPreferences=getSharedPreferences(Mypreferences, Context.MODE_PRIVATE);
        wid=sharedPreferences.getString(WordID,"");

        bindlist();

        disdpt.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final String m = list2.get(position).toString();
                final int Did = Integer.parseInt(m);

                AlertDialog.Builder ab = new AlertDialog.Builder(DisplayDeptActivity.this);
                ab.setMessage("R U Sure You Want to Delete?");

                ab.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (obj.deletedpt(Did)) {
                            showmsg("Record Deleted!");
                            bindlist();
                        }
                    }
                });

                ab.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showmsg("Record Not Deleted!");
                    }
                });

                AlertDialog ad = ab.create();
                ad.show();
            }
        });
    }

    public void showmsg (String msg)
    {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }

    public void bindlist ()
    {
        list = new ArrayList<String >();
        list1 = new ArrayList<String>();
        list2 = new ArrayList<String>();
        list3 = new ArrayList<String>();
        Cursor c = obj.getdept(wid);

        int Didindex = c.getColumnIndex("Did");
        int Widindex = c.getColumnIndex("Wid");
        int Dnameindex = c.getColumnIndex("Dname");

        while (c.moveToNext()) {
            list2.add(c.getString(Didindex));
            list3.add(c.getString(Widindex));
            list1.add(c.getString(Dnameindex));
            list.add(c.getString(Didindex) + " " + c.getString(Dnameindex));
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter(DisplayDeptActivity.this, android.R.layout.simple_list_item_1, list);
        disdpt.setAdapter(arrayAdapter);
    }
}

    

