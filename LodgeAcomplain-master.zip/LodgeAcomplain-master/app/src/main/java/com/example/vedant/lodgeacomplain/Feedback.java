package com.example.vedant.lodgeacomplain;

public class Feedback {
    private String cname,mob1,feedback1;
    int cid;
    private byte[] image;
    private String description;

    public Feedback(String Cname,String mob,String feedback2){
        cname=Cname;
        mob1=mob;
        feedback1=feedback2;
    }
    public String getname(){return cname;}
    public String getmob(){return mob1;}
    public String getfeedback(){return feedback1;}

}
