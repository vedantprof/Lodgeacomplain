package com.example.vedant.lodgeacomplain;

import android.content.Intent;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import static android.provider.ContactsContract.CommonDataKinds.*;

public class ForgetPass extends AppCompatActivity {

    private static final Object Email = "email";
    EditText frgtmail;
    Button frgtbtn;
    TextView dispass;
    DbHepler obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_pass);

        obj = new DbHepler(this);
        frgtmail = (EditText)findViewById(R.id.frgtmail);
        frgtbtn = (Button)findViewById(R.id.frgtbtn);
        dispass = (TextView)findViewById(R.id.dispass);

//        frgtbtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String s1= frgtmail.getText().toString();
//                Cursor c = obj.getaemail(s1);
//                Cursor c1 = obj.getwmail(s1);
//
//                try
//                {
//                    if(c.getCount()>0)
//                    {
//                        In
//                    }
//                }
//                catch (Exception e)
//                {
//
//                }
//            }
//        });
    }

    public void showmsg(String msg)
    {
        Toast.makeText(this, msg , Toast.LENGTH_SHORT).show();
    }
}
