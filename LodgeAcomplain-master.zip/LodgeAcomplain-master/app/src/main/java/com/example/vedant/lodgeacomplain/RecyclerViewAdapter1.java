package com.example.vedant.lodgeacomplain;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class RecyclerViewAdapter1 extends RecyclerView.Adapter<RecyclerViewAdapter1.Viewholder1> {



    private List<Wardwisecomplain> aproperty;
    Context context;
    public RecyclerViewAdapter1(List<Wardwisecomplain> properties, WardNavigationActivity wardNavigationActivity) {
        this.aproperty=properties;
        this.context=wardNavigationActivity;
    }

    @NonNull
    @Override
    public Viewholder1 onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        Context context =viewGroup.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View contactView = inflater.inflate(R.layout.item_holder1,viewGroup, false);
        Viewholder1 viewHolder = new Viewholder1(contactView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder1 viewholder1, int i) {
        Wardwisecomplain property=aproperty.get(i);
        Wardwisecomplain property1=aproperty.get(i);
        TextView name=viewholder1.name;
        name.setText(property.getname());
        TextView address=viewholder1.description;
        address.setText(property.getdescription());
        ImageView imageView=viewholder1.imageView;

        final String s1 = Integer.toString(property.getid());
        final String s2 = property.getname();

        if (property.getimage()!=null) {
            imageView.setImageBitmap(BitmapFactory.decodeByteArray(property.getimage(), 0, property.getimage().length));
        }

        viewholder1.cardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, ActionActivity.class);
                i.putExtra("a1",s1);
                i.putExtra("a2",s2);
                context.startActivity(i);
            }
        });


    }

    @Override
    public int getItemCount() {
        return aproperty.size();
    }

    public class Viewholder1 extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView name;
        public TextView description;
        public ImageView imageView;
        public CardView cardView1;
        ItemClickListner itemClickListener;
        public Viewholder1(@NonNull View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.allcomptv12);
            //address=itemView.findViewById(R.id.thomeaddress);
            imageView = itemView.findViewById(R.id.allcompimg2);
            cardView1 = itemView.findViewById(R.id.allcompcv2);
            description = itemView.findViewById(R.id.allcomptv22);
            ItemClickListner itemClickListner;
        }

        @Override
        public void onClick(View v)
        {
            this.itemClickListener.onItemclick(v,getLayoutPosition());
        }
        public void setItemClickListener(ItemClickListner itemClickListener)
        {
            this.itemClickListener = itemClickListener;
        }
    }
}
