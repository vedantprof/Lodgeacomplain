package com.example.vedant.lodgeacomplain;

public class Complain {
private String cname;
int cid;
private byte[] image;
private String description;

public Complain(String Cname,int Cid,byte[] image1,String description1){
    cname=Cname;
    cid=Cid;
    image=image1;
    description=description1;
}
public String getname(){return cname;}
public int getid(){return cid;}
public byte[] getimage(){return image;}
public String getdescription(){return description;}
}
