package com.example.vedant.lodgeacomplain;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FeedbackActivity extends AppCompatActivity {
    EditText fname,fmob,femail,fdes;
    Button fbtn;
    DbHepler obj;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        obj = new DbHepler(this);
        startconfig();

        fbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Fname = fname.getText().toString();
                String Fmob = fmob.getText().toString();
                String Femail = femail.getText().toString();
                String Fdes = fdes.getText().toString();

                try
                {

                    if (obj.addfdbk(Fname, Fmob, Femail, Fdes))
                    {
                        showmsg("Feedback Added.");
                        clrtext();
                    }
                    else
                    {
                        showmsg("Not added.");
                    }
                }
                catch (Exception e)
                {
                    showmsg(e.toString());
                }
            }
        });
    }

    public void startconfig()
    {
        fname = (EditText)findViewById(R.id.fname);
        fmob = (EditText)findViewById(R.id.fmob);
        femail = (EditText)findViewById(R.id.femail);
        fdes = (EditText)findViewById(R.id.fdes);
        fbtn = (Button)findViewById(R.id.fbtn);
    }

    public void showmsg(String msg)
    {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    public void clrtext()
    {
        fname.setText("");
        fmob.setText("");
        femail.setText("");
        fdes.setText("");
    }
}
