package com.example.vedant.lodgeacomplain;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class ServicesActivity extends AppCompatActivity {
    Spinner deptbind;
    EditText sname;
    Button addser,disser;
    DbHepler obj;
    ArrayList<String> list,list1,list2,list3;
    int id;
    SharedPreferences sharedPreferences;

    public static final String Mypreferences="MyLogin";
    public  static final String WordID="wordkey";
    String wid="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services);

        obj=new DbHepler(this);
        startconfig();
        sharedPreferences=getSharedPreferences(Mypreferences, Context.MODE_PRIVATE);
        wid=sharedPreferences.getString(WordID,"");
        dbind();

        deptbind.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String w = list1.get(position);
                id = Integer.parseInt(w);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        addser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Sname = sname.getText().toString();

                try
                {
                    if(obj.addservices(id,Sname))
                    {
                        showmessage("Added.");
                        clrtext();
                    }
                    else
                    {
                        showmessage("Failed!!");
                    }
                }
                catch (Exception e)
                {
                    showmessage(e.toString());
                }
            }
        });

        disser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),DisplayServiceActivity.class);
                startActivity(i);
            }
        });
    }

    public void startconfig()
    {
        deptbind = (Spinner)findViewById(R.id.deptbind);
        sname = (EditText)findViewById(R.id.sname);
        addser = (Button)findViewById(R.id.addser);
        disser = (Button)findViewById(R.id.disser);
    }

    public void dbind()
    {
        list = new ArrayList<String>();
        list1 = new ArrayList<String>();
        Cursor c = obj.getdept(wid);

        final int Dname = c.getColumnIndex("Dname");
        final int Did= c.getColumnIndex("Did");
        while(c.moveToNext())
        {
            list.add(c.getString(Dname));
            list1.add(c.getString(Did));
        }

        ArrayAdapter arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_spinner_item,list);
        deptbind.setAdapter(arrayAdapter);
    }

    public void showmessage(String msg)
    {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    public void clrtext()
    {
        sname.setText("");
    }
}
