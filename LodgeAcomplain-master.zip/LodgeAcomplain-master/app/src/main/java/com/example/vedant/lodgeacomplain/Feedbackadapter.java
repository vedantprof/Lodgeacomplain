package com.example.vedant.lodgeacomplain;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class Feedbackadapter extends RecyclerView.Adapter<Feedbackadapter.FdViewholder> {
    private List<Feedback> aproperty;
    Context context;
    public Feedbackadapter(List<Feedback> properties, AdminNavigation adminNavigation) {
        this.aproperty=properties;
        this.context=adminNavigation;
    }

    @NonNull
    @Override
    public FdViewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        Context context =viewGroup.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View contactView = inflater.inflate(R.layout.feedbackviewholder,viewGroup, false);
        FdViewholder viewHolder=new FdViewholder(contactView);
        return viewHolder;    }

    @Override
    public void onBindViewHolder(@NonNull FdViewholder fdViewholder, int i) {
        Feedback property=aproperty.get(i);
        Feedback property1=aproperty.get(i);
        TextView name=fdViewholder.name;
        name.setText(property.getname());
        TextView address=fdViewholder.mob;
        address.setText(property.getmob());
        TextView feedback=fdViewholder.feedback;
        feedback.setText(property.getfeedback());

    }

    @Override
    public int getItemCount() {
        return aproperty.size();
    }

    public class FdViewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView name,mob,feedback;
        public TextView description;
        public ImageView imageView;
        public CardView cardView1;
        ItemClickListner itemClickListener;
        public FdViewholder(@NonNull View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.fd1);
            //address=itemView.findViewById(R.id.thomeaddress);
            mob=itemView.findViewById(R.id.fd2);
            feedback=itemView.findViewById(R.id.fd3);
            ItemClickListner itemClickListner;
        }

        @Override
        public void onClick(View v) {
            this.itemClickListener = itemClickListener;
        }
    }
}
