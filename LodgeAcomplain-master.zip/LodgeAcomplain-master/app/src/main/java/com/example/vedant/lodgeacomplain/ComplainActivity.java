package com.example.vedant.lodgeacomplain;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class ComplainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_GALLERY =999 ;
    TextView rst;
    ImageView imgview;
    Button submitbtn,cambtn,gallarybtn;
    EditText pname, pemail, paddress, compdes;
    ArrayList<String> list,list1,list2,list3,list4,list5,list6,list7,list8,list9,list10;
    Spinner pdwrd,pdarea,compsp,ctypesp;
    ArrayAdapter ap;
    DbHepler obj;
    int id1,id3,id4,id5;
    SharedPreferences sharedPreferences;

    public static final String Mypreferences="MyLogin";
    public  static final String WordID="wordkey";
    String wid="";
    private static final int CAMERA_REQUEST = 1888;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complain);

        obj = new DbHepler(this);
        startconfig();
        sharedPreferences=getSharedPreferences(Mypreferences, Context.MODE_PRIVATE);
        wid=sharedPreferences.getString(WordID,"");
        ward();
        area();
        dept();
        serv();

        pdwrd.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String h = list.get(position);
                id1 = Integer.parseInt(h);

                ArrayList<String> dlt1=new ArrayList<String>();
                ArrayList<String> dlt2=new ArrayList<String>();
                ArrayList<String> dlt3=new ArrayList<String>();
                ArrayList<String> dlt4=new ArrayList<String>();
                Cursor c1 = obj.getdept(h);

                final int Did = c1.getColumnIndex("Did");

                final int Dname = c1.getColumnIndex("Dname");
                while (c1.moveToNext())
                {
                    dlt1.add(c1.getString(Did));

                    dlt2.add(c1.getString(Dname));
                }
                ArrayAdapter ap = new ArrayAdapter(ComplainActivity.this, android.R.layout.simple_list_item_1,dlt2);
                compsp.setAdapter(ap);


                //Area Bind

                 Cursor c2 = obj.getwareas(id1);


                final int Arid = c2.getColumnIndex("Arid");
                final int Arname = c2.getColumnIndex("Arname");
                while (c2.moveToNext())
                {
                    dlt3.add(c2.getString(Arid));

                    dlt4.add(c2.getString(Arname));
                }
                ArrayAdapter arrayAdapter = new ArrayAdapter(ComplainActivity.this, android.R.layout.simple_list_item_1, dlt4);
                pdarea.setAdapter(arrayAdapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        pdarea.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String w = list8.get(position);
                id3 = Integer.parseInt(w);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        compsp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String q = list9.get(position);
                id4 = Integer.parseInt(q);

                ArrayList<String> dlt5=new ArrayList<String>();
                ArrayList<String> dlt6=new ArrayList<String>();
                Cursor c2 = obj.getdser(id4);


                final int Sid = c2.getColumnIndex("Sid");
                final int Sname = c2.getColumnIndex("Sname");
                // showmsg(Wid+"and"+Aid+"and"+Arname);
                while (c2.moveToNext())
                {
                    dlt5.add(c2.getString(Sid));
                    dlt6.add(c2.getString(Sname));
                }
                ArrayAdapter arrayAdapter = new ArrayAdapter(ComplainActivity.this, android.R.layout.simple_list_item_1, dlt6);
                ctypesp.setAdapter(arrayAdapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ctypesp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String a = list10.get(position);
                id5 = Integer.parseInt(a);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        cambtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,CAMERA_REQUEST);
            }
        });

        gallarybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent,REQUEST_CODE_GALLERY);
            }
        });

        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Pname = pname.getText().toString();
                String Pemail = pemail.getText().toString();
                String Paddress = paddress.getText().toString();
                String Compdesc = compdes.getText().toString();

                if (!isNullrec(Pname)){
                    pname.setError("Fill Text");
                }
                if(!isNullrec(Pemail)){
                    pemail.setError("Fill Text");
                }
                if(!isNullrec(Paddress)){
                    paddress.setError("Fill Text");
                }
                if(!isValidEmailId(Pemail)){
                    pemail.setError("invalid EmailId");
                }
                if(!isNullrec(Compdesc))
                {
                    compdes.setError("Fill Text");
                }

                if((isValidEmailId(Pemail))) {
                    try
                    {
                        if (obj.addc(Pname, Pemail, Paddress, id1, id3, id4, id5, Compdesc,imageviewtobyte(imgview))) {
                            showmsg("Your complain is successfully registered..");
                            clrtext();
                        } else {
                            showmsg("Failed!!");
                        }
                    } catch (Exception e) {
                        showmsg(e.toString());
                    }
                }
                }
        });

        rst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clrtext();
            }
        });


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new
                        Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }

        }
    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
//            Bitmap photo = (Bitmap) data.getExtras().get("data");
//            ViewGroup.LayoutParams layoutParams=imgview.getLayoutParams();
////            layoutParams.height=300;
////            layoutParams.width=500;
//            imgview.setLayoutParams(layoutParams);
//            imgview.setImageBitmap(photo);
//        }
//    }

    public void startconfig()
    {
        rst = (TextView)findViewById(R.id.rst);
        imgview = (ImageView)findViewById(R.id.imgview);
        submitbtn = (Button)findViewById(R.id.submitbtn);
        cambtn = (Button)findViewById(R.id.cambtn);
        gallarybtn = (Button)findViewById(R.id.gallarybtn);
        pname = (EditText)findViewById(R.id.pname);
        pemail = (EditText)findViewById(R.id.pemail);
        paddress = (EditText)findViewById(R.id.fmob);
        compdes = (EditText)findViewById(R.id.compdes);
        pdwrd = (Spinner)findViewById(R.id.pdwrd);
        pdarea = (Spinner)findViewById(R.id.pdarea);
        compsp = (Spinner)findViewById(R.id.compsp);
        ctypesp = (Spinner)findViewById(R.id.ctypesp);
    }

    public void clrtext()
    {
        pname.setText("");
        pemail.setText("");
        paddress.setText("");
        compdes.setText("");
    }

    public void ward()
    {
        list = new ArrayList<String>();
        list1 = new ArrayList<String>();
        Cursor c1 = obj.getwards();

        final int Wid = c1.getColumnIndex("Wid");
        final int Wno = c1.getColumnIndex("Wno");
        while (c1.moveToNext())
        {
            list.add(c1.getString(Wid));
            list1.add(c1.getString(Wno));
        }
        ap = new ArrayAdapter(ComplainActivity.this, android.R.layout.simple_list_item_1,list1);
        pdwrd.setAdapter(ap);
    }

    public void area()
    {
        list8 = new ArrayList<String>();
        list2 = new ArrayList<String>();
        list3 = new ArrayList<String>();
        Cursor c1 = obj.getareas();

        final int Wid = c1.getColumnIndex("Wid");
        final int Aid = c1.getColumnIndex("Arid");
        final int Arname = c1.getColumnIndex("Arname");
       // showmsg(Wid+"and"+Aid+"and"+Arname);
        while (c1.moveToNext())
        {
            list8.add(c1.getString(Aid));
            list2.add(c1.getString(Wid));
            list3.add(c1.getString(Arname));
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter(ComplainActivity.this, android.R.layout.simple_list_item_1, list3);
        pdarea.setAdapter(arrayAdapter);
    }

    public void dept()
    {
        list9 = new ArrayList<String>();
        list4 = new ArrayList<String>();
        list5 = new ArrayList<String>();
//        Cursor c1 = obj.getdept(wid);
        Cursor c1 = obj.getdeptall();

        final int Did = c1.getColumnIndex("Did");
        final int Wid = c1.getColumnIndex("Wid");
        final int Dname = c1.getColumnIndex("Dname");
        while (c1.moveToNext())
        {
            list9.add(c1.getString(Did));
            list4.add(c1.getString(Wid));
            list5.add(c1.getString(Dname));
        }
        ap = new ArrayAdapter(ComplainActivity.this, android.R.layout.simple_list_item_1, list5);
        compsp.setAdapter(ap);

    }

    public void serv()
    {
        list10 = new ArrayList<String>();
        list6 = new ArrayList<String>();
        list7 = new ArrayList<String>();
        Cursor c1 = obj.getservices();

        final int Sid = c1.getColumnIndex("Sid");
        final int Did = c1.getColumnIndex("Did");
        final int Sname = c1.getColumnIndex("Sname");
        while (c1.moveToNext())
        {
            list10.add(c1.getString(Sid));
            list6.add(c1.getString(Did));
            list7.add(c1.getString(Sname));
        }
        ap = new ArrayAdapter(ComplainActivity.this, android.R.layout.simple_list_item_1, list7);
        ctypesp.setAdapter(ap);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        // Check which request it is that we're responding to
        // Make sure the request was successful
        if(requestCode==REQUEST_CODE_GALLERY && resultCode==RESULT_OK && data!=null)
        {
            // Get the URI that points to the selected contact
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                imgview.setImageBitmap(bitmap);
                showmsg("Image Display");

            } catch (Exception ex) {
                showmsg(ex.getMessage());
            }
        }
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
              Bitmap photo = (Bitmap) data.getExtras().get("data");
              ViewGroup.LayoutParams layoutParams=imgview.getLayoutParams();
                //layoutParams.height=300;
                //layoutParams.width=300;
              imgview.setLayoutParams(layoutParams);
              imgview.setImageBitmap(photo); }
        super.onActivityResult(requestCode, resultCode, data);
    }
    //Step 4 important
    public byte[] imageviewtobyte(ImageView imageView)
    {
        Bitmap bitmap=((BitmapDrawable)imageView.getDrawable()).getBitmap();
        ByteArrayOutputStream stream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,50,stream);
        byte[] bytearray=stream.toByteArray();
        return bytearray;
    }


    public void showmsg(String msg)
    {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private boolean isNullrec(String n){

        if (n!=""&&n.length()>0){
            return true;
        }
        return false;
    }

    private boolean isValidEmailId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();

    }
}
