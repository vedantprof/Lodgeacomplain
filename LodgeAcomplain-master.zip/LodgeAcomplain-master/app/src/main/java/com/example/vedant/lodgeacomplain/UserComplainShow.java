package com.example.vedant.lodgeacomplain;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class UserComplainShow extends AppCompatActivity {

    RecyclerView wardwise;
    DbHepler obj;

    ArrayList<String> list1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_complain_show);
        wardwise=findViewById(R.id.usercomp);
        final String m = getIntent().getStringExtra("name");
        obj=new DbHepler(this);


        Cursor d = obj.showallcomplain();
        int propertyname = d.getColumnIndex("Cname");
        int description=d.getColumnIndex("Cdesc");
        int proimage = d.getColumnIndex("Cimg");
        int pid = d.getColumnIndex("Cid");
        int wid = d.getColumnIndex("Wid");
        List<Wardwisecomplain> properties = new ArrayList<>();
        int i = 0;
        if (d.getCount() != 0) {
            while (d.moveToNext()) {
                Wardwisecomplain property1 = new Wardwisecomplain(d.getString(propertyname), d.getInt(pid), d.getInt(wid), d.getBlob(proimage),d.getString(description));
                properties.add(i, property1);
                i++;
            }
            UserRecycle adapter = new UserRecycle(properties, this);
            wardwise.setAdapter(adapter);
            wardwise.setLayoutManager((new LinearLayoutManager(this)));
        } else {
            Toast.makeText(UserComplainShow.this, "There is no data to show!", Toast.LENGTH_LONG).show();
        }

    }
}
