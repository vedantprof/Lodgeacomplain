package com.example.vedant.lodgeacomplain;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.http.SslCertificate;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.QuickContactBadge;
import android.widget.Toast;

public class DepartmentActivity extends AppCompatActivity {
    EditText dname;
    Button adddept,deletedept;
    DbHepler obj;
    SharedPreferences sharedPreferences;

    public static final String Mypreferences="MyLogin";
    public  static final String WordID="wordkey";
    String wid="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department);

        obj = new DbHepler(this);
        starconfig();
        sharedPreferences=getSharedPreferences(Mypreferences, Context.MODE_PRIVATE);
        wid=sharedPreferences.getString(WordID,"");

        adddept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Dname = dname.getText().toString();

                try
                {
                    if(obj.adddept(wid,Dname))
                    {
                        showmessage("Added.");
                        clrtext();
                    }
                    else
                    {
                        showmessage("Failed!!");
                    }
                }
                catch (Exception e)
                {
                    showmessage(e.toString());
                }
            }
        });

        deletedept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),DisplayDeptActivity.class);
                startActivity(i);
            }
        });
    }

    public void starconfig()
    {
        dname = (EditText)findViewById(R.id.Dname);
        adddept = (Button)findViewById(R.id.adddept);
        deletedept = (Button)findViewById(R.id.deletedept);
    }

    public void showmessage(String msg)
    {
        Toast.makeText(this,msg, Toast.LENGTH_SHORT).show();
    }

    public void clrtext()
    {
        dname.setText("");
    }
}
