package com.example.vedant.lodgeacomplain;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class DisplayServiceActivity extends AppCompatActivity {
    ListView serlst;
    ArrayList list,list1,list2,list3,list4;
    DbHepler obj;
    SharedPreferences sharedPreferences;

    public static final String Mypreferences="MyLogin";
    public  static final String WardID="wardkey";
    public static final String DeptID="deptkey";
    String did="";
    String wid="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_service);

        sharedPreferences=getSharedPreferences(Mypreferences, Context.MODE_PRIVATE);
//        wid=sharedPreferences.getString(WardID,"");
        did=sharedPreferences.getString(DeptID,"");

        obj = new DbHepler(this);
        serlst = (ListView)findViewById(R.id.serlst);
        bindlist();

        serlst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final String m = list2.get(position).toString();
                final int Sid = Integer.parseInt(m);

                AlertDialog.Builder ab = new AlertDialog.Builder(DisplayServiceActivity.this);
                ab.setMessage("R U Sure You Want to Delete?");

                ab.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (obj.deleteser(Sid)) {
                            showmsg("Record Deleted!");
                            bindlist();
                        }
                    }
                });

                ab.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showmsg("Record Not Deleted!");
                    }
                });

                AlertDialog ad = ab.create();
                ad.show();
            }
        });
    }
    public void bindlist ()
    {
        list = new ArrayList<String >();
        list1 = new ArrayList<String>();
        list2 = new ArrayList<String>();
        list3 = new ArrayList<String>();
        list4 = new ArrayList<String>();
        Cursor c = obj.getservices();

        int Sidindex = c.getColumnIndex("Sid");
        int Didindex = c.getColumnIndex("Did");
//        int Widindex = c.getColumnIndex("Wid");
        int Snameindex = c.getColumnIndex("Sname");

        while (c.moveToNext()) {
            list2.add(c.getString(Sidindex));
            list3.add(c.getString(Didindex));
//            list4.add(c.getString(Widindex));
            list1.add(c.getString(Snameindex));
            list.add(c.getString(Sidindex) + " " + c.getString(Snameindex));
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter(DisplayServiceActivity.this, android.R.layout.simple_list_item_1, list);
        serlst.setAdapter(arrayAdapter);
    }

    public void showmsg(String msg)
    {
        Toast.makeText(this, msg , Toast.LENGTH_SHORT).show();
    }
}

