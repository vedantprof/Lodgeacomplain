package com.example.vedant.lodgeacomplain;

import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class Usershow extends AppCompatActivity {
    TextView t1,t2,t3;
    ImageView iv4;
    EditText et1;
    Button btn;
    DbHepler obj;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usershow);
        obj=new DbHepler(this);
        btn=findViewById(R.id.enteraction);
        t1 = (TextView)findViewById(R.id.textView51);
        t3 = (TextView)findViewById(R.id.textView61);
        t2=findViewById(R.id.action1);
        iv4=findViewById(R.id.imageView41);
        String n1 = getIntent().getStringExtra("a1");
        String n2 = getIntent().getStringExtra("a2");
        final int id=Integer.parseInt(n1);
        Cursor c=obj.getcompid(id);
        c.moveToFirst();
        byte[] image=c.getBlob(c.getColumnIndex("Cimg"));
        String desc=c.getString(c.getColumnIndex("Cdesc"));
        String status=c.getString(c.getColumnIndex("Cstatus"));
        String action =c.getString(c.getColumnIndex("Caction"));
        t1.setText(n2);
        t2.setText(action);
        t3.setText(status);
        if (image!=null){
            iv4.setImageBitmap(BitmapFactory.decodeByteArray(image,0,image.length));
        }

    }
}
