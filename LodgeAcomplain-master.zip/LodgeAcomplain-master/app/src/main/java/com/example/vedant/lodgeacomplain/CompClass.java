package com.example.vedant.lodgeacomplain;

public class CompClass {
    int id;
    String name,type;
    byte[] gimage;

    public  CompClass(int gid,String gname,String type,byte[]gimage)
    {
        this.id=gid;
        this.name=gname;
        this.gimage=gimage;
        this.type=type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public byte[] getGimage() {
        return gimage;
    }

    public void setGimage(byte[] gimage) {
        this.gimage = gimage;
    }
}
