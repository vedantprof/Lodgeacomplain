package com.example.vedant.lodgeacomplain;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.Integer;
import java.util.Random;

public class UserSignupActivity extends AppCompatActivity {
    EditText unum;
    Button btn1,btn2;
    DbHepler obj;
    //TextView t1;
    int otp;
    int sendotp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_signup);

        obj = new DbHepler(this);
        unum = (EditText)findViewById(R.id.unum);
        btn1 = (Button)findViewById(R.id.otp);
        btn2 = (Button)findViewById(R.id.backbtn2);
      //  t1 = (TextView)findViewById(R.id.t12) ;
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String num = unum.getText().toString();
//
//                try
//                {
//                    if(obj.adduser(num))
//                    {
//
//                    }
//                }
//                catch (Exception e)
//                {
//
//                }
                if(num.length()==10 || num.equals(" ")) {
                    otp = random();
                    sendotp = otp;
                    String msg = "Your OTP : " + otp;
                    String s1 = Integer.toString(sendotp);

                    Intent i = new Intent(getApplicationContext(), OtpActivity.class);
                    i.putExtra("otp", s1);
                    startActivity(i);
                    finish();
                    try {
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(num, null, msg, null, null);

                    } catch (Exception ex) {
                        showmsg(ex.getMessage());
                        //et1.setText(ex.getMessage());
                    }
                }
                else
                {
                    unum.setError("Please Enter Valid Mobile Number");
                }
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),NavigationActivity.class);
                startActivity(i);
                finish();
            }
        });


    }
    public void showmsg(String msg)
    {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
    public int random()
    {
        int v;
        Random r=new Random();
        v=r.nextInt(9999);
        return v;
    }
}