package com.example.vedant.lodgeacomplain;

import android.content.DialogInterface;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class disward extends AppCompatActivity {
    ListView listward;
    DbHepler obj;
    ArrayList list, list1, list2, list3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disward);

//        obj = new DbHepler(this);
//
//        startconfig();
//        listbind();
//
//        listward.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                final String m = list2.get(position).toString();
//                final int Wid = Integer.parseInt(m);
//                showmsg(""+Wid);
//
//                AlertDialog.Builder ab = new AlertDialog.Builder(getApplicationContext());
//                ab.setMessage("R U Sure You Want to Delete?");
//
//                 ab.setPositiveButton("YES", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        if (obj.deleteward(Wid)) {
//                            showmsg("Record Deleted!");
//                            listbind();
//                        }
//                    }
//                });
//
//                ab.setNegativeButton("NO", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        showmsg("Record Not Deleted!");
//                    }
//                });
//
//                AlertDialog ad = ab.create();
//                ad.show();
//            }
//        });
//    }
//
//    private void showmsg(String msg) {
//        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
//    }
//
//    public void startconfig()
//    {
//        listward = (ListView)findViewById(R.id.listward);
//    }
//
//    public void listbind()
//    {
//        list1 = new ArrayList();
//        list2 = new ArrayList();
//        Cursor c = obj.getwards();
//        int Widindex = c.getColumnIndex("Wid");
//        int Wnoindex = c.getColumnIndex("Wno");
//        int Wemailindex = c.getColumnIndex("Wemail");
//        int Wpwdindex = c.getColumnIndex("Wpwd");
//
//        while (c.moveToNext())
//        {
//            list2.add(c.getString(Widindex));
//            list1.add(c.getString(Wnoindex));
//        }
//        ArrayAdapter arrayAdapter = new ArrayAdapter<String>(disward.this,android.R.layout.simple_list_item_1,list1);
//        listward.setAdapter(arrayAdapter);

        obj = new DbHepler(this);
        listward = (ListView) findViewById(R.id.listward);
        bindlist();

        listward.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final String m = list2.get(position).toString();
                final int Wid = Integer.parseInt(m);

                AlertDialog.Builder ab = new AlertDialog.Builder(disward.this);
                ab.setMessage("R U Sure You Want to Delete?");

                ab.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (obj.deleteward(Wid)) {
                            showmsg("Record Deleted!");
                            bindlist();
                        }
                    }
                });

                ab.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showmsg("Record Not Deleted!");
                    }
                });

                AlertDialog ad = ab.create();
                ad.show();
            }
        });
    }

    public void bindlist ()
    {
        list = new ArrayList<String>();
        list1 = new ArrayList<String>();
        list2 = new ArrayList<String>();
        list3 = new ArrayList<>();
        Cursor c = obj.getwards();

        int Widindex = c.getColumnIndex("Wid");
        int Zidindex = c.getColumnIndex("Zid");
        int Wnoindex = c.getColumnIndex("Wno");
        int Wemailindex = c.getColumnIndex("Wemail");
        int Wpwdindex = c.getColumnIndex("Wpwd");

        while (c.moveToNext()) {
            list2.add(c.getString(Widindex));
            list3.add(c.getString(Zidindex));
            list1.add(c.getString(Wnoindex));
            list.add(c.getString(Widindex) + " " + c.getString(Wnoindex) + " " + c.getString(Wemailindex) + " " + c.getString(Wpwdindex));
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter(disward.this, android.R.layout.simple_list_item_1, list);
        listward.setAdapter(arrayAdapter);
    }
    public void showmsg (String msg)
    {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }
}

