package com.example.vedant.lodgeacomplain;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class AddAreaActivity extends AppCompatActivity {
    Spinner sarea2;
    EditText arname;
    Button addarea,darea;
    DbHepler obj;
    ArrayList<String> list,list1,list2,list3,list4,list5;
    int id1;
    ArrayAdapter ap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_area);

        obj = new DbHepler(this);
        startconfig();

//        zone();
//
//        sarea1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                String w = list1.get(position);
//                id1 = Integer.parseInt(w);

//                list1 = new ArrayList<>();
//                list3 = new ArrayList<>();
//                list4 = new ArrayList<>();
//                Cursor c1 = obj.getw(id1);
//
//                final int Zid = c1.getColumnIndex("Zid");
//                final int Wid = c1.getColumnIndex("Wid");
//                final int Wno = c1.getColumnIndex("Wno");
//                while (c1.moveToNext()) {
//                    list1.add(c1.getString(Zid));
//                    list3.add(c1.getString(Wid));
//                    list4.add(c1.getString(Wno));
//                }
//
//                ArrayAdapter ArrayAdapter = new ArrayAdapter(AddAreaActivity.this, android.R.layout.simple_spinner_item, list4);
//                sarea2.setAdapter(ArrayAdapter);
//            }

//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });

        ward();

        sarea2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String h = list3.get(position);
                id1 = Integer.parseInt(h);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        addarea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Arname = arname.getText().toString();

                try
                {
                    if(obj.addarea(id1,Arname))
                    {
                        showmessage("Added.");
                        clrtext();
                    }
                    else
                    {
                        showmessage("Failed!!");
                    }
                }
                catch (Exception e)
                {
                    showmessage(e.toString());
                }
            }
        });

        darea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),DisplayAreaActivity.class);
                startActivity(i);
            }
        });
    }

    public void startconfig()
    {
//        sarea1 = (Spinner)findViewById(R.id.zsp);
        sarea2 = (Spinner)findViewById(R.id.wsp);
        arname = (EditText)findViewById(R.id.arname);
        addarea = (Button)findViewById(R.id.addarea);
        darea = (Button)findViewById(R.id.darea);
    }

//    public void zone()
//    {
//        list1 = new ArrayList<String>();
//        list2= new ArrayList<String>();
//        Cursor c = obj.getzones();
//
//        final int Zid = c.getColumnIndex("Zid");
//        final int Zname= c.getColumnIndex("Zname");
//        while(c.moveToNext())
//        {
//            list1.add(c.getString(Zid));
//            list2.add(c.getString(Zname));
//        }
//
//        ArrayAdapter arrayAdapter=new ArrayAdapter(AddAreaActivity.this,android.R.layout.simple_spinner_item,list2);
//        sarea1.setAdapter(arrayAdapter);
//    }

    public void ward()
    {
        list = new ArrayList<String>();
        list3 = new ArrayList<String>();
        list4= new ArrayList<String>();
        Cursor c1 = obj.getwards();

        final int Zid = c1.getColumnIndex("Zid");
        final int Wid = c1.getColumnIndex("Wid");
        final int Wno = c1.getColumnIndex("Wno");
            while (c1.moveToNext())
            {
                list.add(c1.getString(Zid));
                list3.add(c1.getString(Wid));
                list4.add(c1.getString(Wno));
            }
            ap = new ArrayAdapter(AddAreaActivity.this, android.R.layout.simple_list_item_1, list4);
            sarea2.setAdapter(ap);
    }

    public void showmessage(String msg)
    {
        Toast.makeText(this,msg, Toast.LENGTH_SHORT).show();
    }

    public void clrtext()
    {
        arname.setText("");
    }
}
