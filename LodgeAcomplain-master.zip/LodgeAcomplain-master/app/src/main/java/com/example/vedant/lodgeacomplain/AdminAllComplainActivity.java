package com.example.vedant.lodgeacomplain;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class AdminAllComplainActivity extends AppCompatActivity {
    DbHepler obj;
    RecyclerView allcomplain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_all_complain);
        allcomplain = findViewById(R.id.allcomplain);
        obj = new DbHepler(this);

        Cursor d = obj.showallcomplain();
        int propertyname = d.getColumnIndex("Cname");
        int description=d.getColumnIndex("Cdesc");
        int proimage = d.getColumnIndex("Cimg");
        int pid = d.getColumnIndex("Cid");
        List<Complain> properties = new ArrayList<>();
        int i = 0;
        if (d.getCount() != 0) {
            while (d.moveToNext()) {
                Complain property1 = new Complain(d.getString(propertyname), d.getInt(pid), d.getBlob(proimage),d.getString(description));
                properties.add(i, property1);
                i++;
            }
            RecyclerviewAdapter adapter = new RecyclerviewAdapter(properties, this);
            allcomplain.setAdapter(adapter);
            allcomplain.setLayoutManager((new LinearLayoutManager(this)));
        } else {
            Toast.makeText(AdminAllComplainActivity.this, "There is no data to show!", Toast.LENGTH_LONG).show();
        }
    }
}
