package com.example.vedant.lodgeacomplain;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class OtpActivity extends AppCompatActivity {
    EditText n1,n2,n3,n4;
    Button verbtn;
    int otp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);

        startconfig();

        n1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()==1)
                {
                    n2.requestFocus();
                }
                else if(s.length()==0)
                {

                }
            }
        });

        n2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()==1)
                {
                    n3.requestFocus();
                }
                else if(s.length()==0)
                {
                    n1.requestFocus();
                }
            }
        });

        n3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()==1)
                {
                    n4.requestFocus();
                }
                else if(s.length()==0)
                {
                    n2.requestFocus();
                }
            }
        });

        n4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()==1)
                {
                    n4.clearFocus();
                }
                else if(s.length()==0)
                {
                    n3.requestFocus();
                }
            }
        });

        verbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=getIntent().getStringExtra("otp");
                int otpp=Integer.parseInt(s1);
                int char1=0;
                int char2=0;
                int char3=0;
                int char4=0;

                String get1otp=n1.getText().toString().trim();
                char1=!get1otp.equals("")?Integer.parseInt(get1otp):0;
                String get2otp=n2.getText().toString().trim();
                char2=!get1otp.equals("")?Integer.parseInt(get2otp):0;
                String get3otp=n3.getText().toString().trim();
                char3=!get1otp.equals("")?Integer.parseInt(get3otp):0;
                String get4otp=n4.getText().toString().trim();
                char4=!get1otp.equals("")?Integer.parseInt(get4otp):0;
                int full=((char1*1000)+(char2*100)+(char3*10)+char4);
                
                if(full == otpp)
                {
                    showmsg("Welcome User");
                    Intent i = new Intent(getApplicationContext(),UserNavigation.class);
                    startActivity(i);
                }
                else
                {
                    showmsg("Invalid OTP");
                }
            }
        });
    }

    public void startconfig()
    {
        n1 = (EditText)findViewById(R.id.n1);
        n2 = (EditText)findViewById(R.id.n2);
        n3 = (EditText)findViewById(R.id.n3);
        n4 = (EditText)findViewById(R.id.n4);
        verbtn = (Button)findViewById(R.id.verbtn);
    }

    public void showmsg(String msg)
    {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
