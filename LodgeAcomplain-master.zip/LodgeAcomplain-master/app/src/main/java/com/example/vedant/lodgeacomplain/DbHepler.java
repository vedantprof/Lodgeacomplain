package com.example.vedant.lodgeacomplain;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

public class DbHepler extends SQLiteOpenHelper {


    //public DbHepler(Context context) {
    //    super(context,"main.db",null,1);
    //}

    public DbHepler(Context context) {
        super(context, "main.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Admin(Aid INTEGER PRIMARY KEY AUTOINCREMENT, Aemail varchar(30), Apwd varchar(10))");
        db.execSQL("INSERT INTO Admin(Aemail,Apwd) VALUES ('admin@gmail.com','12345')");
        db.execSQL("Create Table Zone(Zid Integer Primary key Autoincrement, Zname varchar(15))");
        db.execSQL("Insert Into Zone(Zname) Values ('--Select Zone--')");
        db.execSQL("Insert into Zone(Zname) Values ('East - Zone')");
        db.execSQL("Insert into Zone(Zname) Values ('West - Zone')");
        db.execSQL("Insert into Zone(Zname) Values ('North - Zone')");
        db.execSQL("Insert into Zone(Zname) Values ('South - Zone')");
        db.execSQL("CREATE TABLE Ward(Wid INTEGER PRIMARY KEY AUTOINCREMENT, Wno varchar(20), Wemail varchar(30), Wpwd varchar(10), Zid Integer, Foreign Key (Zid) References Zone(Zid))");
        db.execSQL("CREATE TABLE User(Uid INTEGER PRIMARY KEY AUTOINCREMENT, Umob Integer(10))");
        db.execSQL("Create Table Area(Arid Integer Primary key Autoincrement, Arname varchar(20), Zid Integer(02), Wid Integer(02), Foreign key (Zid) References Zone(Zid), Foreign key (Wid) References Ward(Wid))");
        db.execSQL("Create Table Department(Did Integer Primary Key Autoincrement, Wid Integer, Dname varchar(10), Foreign key (Wid) References Ward(Wid))");
        db.execSQL("Insert into Department(Dname) Values ('--Select Department--')");
        db.execSQL("Create TABLE Services(Sid Integer Primary key Autoincrement, Sname varchar(20), Wid Integer, Did Integer, foreign key (Wid) References Ward(Wid), Foreign key (Did) References Department(Did))");
        db.execSQL("Create Table Complain(Cid Integer Primary key, Cimg BLOB, Cstatus varchar DEFAULT 'PENDING', Cdesc varchar(250), Cname varchar(20), Cemail varchar(30), Caddress varchar(50), Uid Integer, Arid Integer, Caction Varchar(100), Wid Integer, Did Integer, Sid Integer, Foreign key (Uid) References User(Uid), Foreign key (Arid) References Area(Arid), Foreign key (Wid) References Ward(Wid), Foreign key (Did) References Department(Did), Foreign key (Sid) References Services(Sid))");
        db.execSQL("Create Table Feedback(Fid Integer Primary key Autoincrement, Fname varchar(25), Femail varchar(25), Fmob Integer(10), Fdesc varchar(50), Uid Integer, Foreign key (Uid) References User(Uid))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    //Insert admin
    public boolean addadmin(String s1, String s2) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Aemail", s1);
        cv.put("Apwd", s2);

        long res = db.insert("Admin", null, cv);

        if (res > 0) {
            return true;
        }
        return false;

    }
    public Cursor showallcomplain(){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("select * from complain",null);
    }

    public Cursor wardwisecomplain(int wid){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("select * from complain where Wid="+wid,null);
    }
    //Insert ward
    public boolean addward(int i, String w0, String w1, String w2) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Zid", i);
        cv.put("Wno", w0);
        cv.put("Wemail", w1);
        cv.put("Wpwd", w2);
        long res = db.insert("Ward", null, cv);

        if (res > 0) {
            return true;
        }
        return false;
    }

    public Cursor getwards() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("select * From Ward", null);
    }

    public Cursor getw(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * From Ward Where Zid =" + id, new String[]{String.valueOf(id)});
    }

    public boolean deleteward(int i) {
        SQLiteDatabase db = this.getWritableDatabase();
        long res = db.delete("Ward", "Wid" + "=?", new String[]{String.valueOf(i)});

        if (res > 0) {
            return true;
        }
        return false;
    }

    public boolean addarea(int Wi, String s1) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
//        cv.put("Zid",Zi);
        cv.put("Wid", Wi);
        cv.put("Arname", s1);

        long res = db.insert("Area", null, cv);

        if (res > 0)
        {
            return true;
        }
        return false;
    }

    public Cursor getareas()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * From Area", null);
    }

    public Cursor getwareas(int wid)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * From Area where Wid=" + wid, null);
    }


    public boolean deletearea(int i)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        long res = db.delete("Area", "Arid" + "=?", new String[]{String.valueOf(i)});

        if (res > 0)
        {
            return true;
        }
        return false;
    }

    public boolean addzone(String s1)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Zname", s1);

        long res = db.insert("Zone", null, cv);

        if (res > 0)
        {
            return true;
        }
        return false;
    }

    public Cursor getzones()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * From Zone", null);
    }

    public Cursor loginadmin(String s1, String s2)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM Admin WHERE Aemail='" + s1 + "' and Apwd='" + s2 + "'", null);
    }

    public Cursor getaemail(String s1)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * From Admin where Aemail=" + s1,null);
    }

    public Cursor loginward(String w1, String w2)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * from Ward WHERE Wemail='" + w1 + "' and Wpwd='" + w2 + "'", null);
    }

    public Cursor getwmail(String s1)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * from Ward where Wemail=" + s1,null);
    }

    public boolean adduser(String s1)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Umob", s1);

        long res = db.insert("User", null, cv);

        if (res > 0)
        {
            return true;
        }
        return false;
    }

    public Cursor loginuser(String Uemail, String Upwd)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * from User WHERE Uemail='" + Uemail + "' and Upwd='" + Upwd + "'", null);
    }

    public boolean adddept(String wid, String s1)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Wid", wid);
        cv.put("Dname", s1);

        long res = db.insert("Department", null, cv);

        if (res > 0)
        {
            return true;
        }
        return false;
    }

    public Cursor getdept(String wid)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * From Department where Wid=" + wid, null);
    }

    public Cursor getdeptall()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * From Department", null);
    }

    public boolean deletedpt(int i)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        long res = db.delete("Department", "Did" + "=?", new String[]{String.valueOf(i)});

        if (res > 0)
        {
            return true;
        }
        return false;
    }

    public boolean addservices(int id, String s1)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Did", id);
        cv.put("Sname", s1);

        long res = db.insert("Services", null, cv);

        if (res > 0)
        {
            return true;
        }
            return false;
    }

    public Cursor getservices()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * From Services", null);
    }

    public Cursor getdservices(String did)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * From Services where Did=" + did , null);
    }

    public Cursor getdser(int sid)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * From Services where Sid=" + sid, null);
    }
    public Cursor getcompid(int id){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("select * from Complain where Cid="+id,null);
    }

    public boolean deleteser (int id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        long res = db.delete("Services", "Sid" + "=?", new String[]{String.valueOf(id)});

        if (res > 0)
        {
            return true;
        }
        return false;
    }

    public void addcomp (int status,String sdesc,String cname,String cemail,String caddress,int uid,int arid,int wid,int did,int sid)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        String q="insert into Complain values(?,?,?,?,?,?,?,?,?,?,?,?)";
        SQLiteStatement st=db.compileStatement(q);
        st.clearBindings();
//        st.bindBlob(1,img);
        st.bindLong(2,status);
        st.bindString(3,sdesc);
        st.bindString(4,cname);
        st.bindString(5,cemail);
        st.bindString(6,caddress);
        st.bindLong(7,uid);
        st.bindLong(8,arid);
        st.bindLong(9,wid);
        st.bindLong(10,did);
        st.bindLong(11,sid);

        st.executeInsert();

    }

    public boolean addc(String s1, String s2, String s3, int i1, int i2, int i3, int i4, String s4,byte[] image)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Cname", s1);
        cv.put("Cemail", s2);
        cv.put("Caddress", s3);
        cv.put("Wid", i1);
        cv.put("Arid", i2);
        cv.put("Did", i3);
        cv.put("Sid", i4);
        cv.put("Cdesc", s4);
        cv.put("Cimg",image);
        long res = db.insert("Complain", null, cv);

        if (res > 0)
        {
            return true;
        }
        return false;
    }

    public String getMyId (String email)
    {
        String e = "";
        Cursor c = loginId(email);
        if (c.getCount() > 0)
        {
            int id = c.getColumnIndex("Wid");
            while (c.moveToNext())
            {
                e = c.getString(id);
            }
        }
        return e;
    }

    public Cursor loginId (String email)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("select * from Ward where Wemail='" + email + "'", null);
    }

    public boolean addimage ( byte[] image)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("gimage", image);
        long res = db.insert("gallery", null, cv);

        if (res > 0)
        {
            return true;

        }
        return false;
    }

    public Cursor showcom(String q)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery(q, null);

    }

    public boolean addfdbk(String s1, String i, String s2, String s3)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Fname", s1);
        cv.put("Fmob", i);
        cv.put("Femail", s2);
        cv.put("Fdesc", s3);

        long res = db.insert("Feedback", null, cv);

        if (res > 0)
        {
            return true;
        }
        return false;
    }

    public Cursor getfdbk()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * From Feedback", null);
    }

    //update complain
    public boolean updatecomplain(int cid, String cstatus, String caction ) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Cstatus", cstatus);
        contentValues.put("Caction", caction);

        long res = db.update("Complain", contentValues, "Cid=" + cid, null);

        if (res > 0) {
            return true;
        }
        return false;
    }
}
