package com.example.vedant.lodgeacomplain;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class RecyclerviewAdapter extends RecyclerView.Adapter<RecyclerviewAdapter.Viewholder> {

    private List<Complain> aproperty;
    Context context;

    public RecyclerviewAdapter(List<Complain> properties, AdminAllComplainActivity adminAllComplainActivity) {
      this.aproperty=properties;
      this.context=adminAllComplainActivity;
    }

    public class Viewholder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public TextView name;
        public TextView description;
        public ImageView imageView;
        public CardView cardView1;
        ItemClickListner itemClickListener;


        public Viewholder(@NonNull View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.allcomptv1);
            //address=itemView.findViewById(R.id.thomeaddress);
            imageView=itemView.findViewById(R.id.allcompimg);
            cardView1=itemView.findViewById(R.id.allcompcv1);
            description=itemView.findViewById(R.id.allcomptv2);
        }

        @Override
        public void onClick(View v) {
            this.itemClickListener.onItemclick(v,getLayoutPosition());
        }
    }


    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        Context context =viewGroup.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View contactView = inflater.inflate(R.layout.itemholder,viewGroup, false);
        Viewholder viewHolder = new Viewholder(contactView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder viewholder, int i) {
        Complain property=aproperty.get(i);
        Complain property1=aproperty.get(i);
        TextView name=viewholder.name;
        name.setText(property.getname());
        TextView address=viewholder.description;
        address.setText(property.getdescription());
        ImageView imageView=viewholder.imageView;
        if (property.getimage()!=null) {
            imageView.setImageBitmap(BitmapFactory.decodeByteArray(property.getimage(), 0, property.getimage().length));
        }
        viewholder.cardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    @Override
    public int getItemCount() {
        return aproperty.size();
    }

}