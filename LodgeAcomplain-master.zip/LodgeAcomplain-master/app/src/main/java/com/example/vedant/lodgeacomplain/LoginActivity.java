package com.example.vedant.lodgeacomplain;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import java.util.regex.Pattern;

public class LoginActivity extends AppCompatActivity {
    DbHepler obj;
    TextView t1;
    EditText et1, et2;
    Button btn1,btn2;

    SharedPreferences sharedPreferences;

    public static final String Mypreferences = "MyLogin";
    public static final String WordID = "wordkey";
    public static final String UserName = "usernamekey";
    public static final String UserContact = "usercontactkey";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        obj = new DbHepler(this);

        startconfig();

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Aemail = et1.getText().toString();
                String Apwd = et2.getText().toString();

                if (!isNullrec(Aemail)){
                    et1.setError("Fill Email");
                }
                if(!isNullrec(Apwd)){
                    et2.setError("Fill Password");
                }
                if(!isValidEmailId(Aemail)){
                    et1.setError("Invalid EmailId");
                }
                if((isNullrec(Aemail))&&(isNullrec(Apwd))) {
                    Cursor c = obj.loginadmin(Aemail, Apwd);
                    Cursor c1 = obj.loginward(Aemail, Apwd);
                    try
                    {
                        if (c.getCount() > 0)
                        {
                            showmsg("Welcome Admin");
                            Intent i = new Intent(getApplicationContext(),AdminNavigation.class);
                            startActivity(i);
                            finish();
                        }
                        else if (c1.getCount() > 0)
                        {
                            sharedPreferences = getSharedPreferences(Mypreferences, Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString(WordID, obj.getMyId(Aemail));
                            //editor.putString(UserName,obj.getMyname(email));
                            //editor.putString(UserContact,obj.getMyContact(email));
                            editor.commit();


                            // showmsg("Welcome Ward"+"and"+obj.getMyId(Aemail));
                            showmsg("Welcome Ward");
                            Intent i = new Intent(getApplicationContext(),WardNavigationActivity.class);
                            i.putExtra("name",Aemail);
                            startActivity(i);
                            finish();
                        }
                        else
                            {
                            showmsg("Invalid Email Or Password");
                        }
                    }
                    catch (Exception e)
                    {
                        showmsg(e.toString());
                    }
                }
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),NavigationActivity.class);
                startActivity(i);
                finish();
            }
        });


//        t1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(getApplicationContext(),ForgetPass.class);
//                startActivity(i);
//            }
//        });
    }

    public void startconfig()
    {
//        t1 = (TextView) findViewById(R.id.frgtpass);
        et1 = (EditText) findViewById(R.id.awemail);
        et2 = (EditText) findViewById(R.id.awpwd);
        btn1 = (Button) findViewById(R.id.mainloginbtn);
        btn2 = (Button)findViewById(R.id.backbtn1);
    }

    public void showmsg(String msg)
    {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

//    public boolean validate()
//    {
//        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
//
//        if (et1.getText().toString().matches(emailPattern))
//        {
//
//            //Toast.makeText(getApplicationContext(),"valid email address",Toast.LENGTH_SHORT).show();
//            return true;
//
//        }
//        else if (!et1.getText().toString().matches(emailPattern))
//        {
//
//            Toast.makeText(getApplicationContext(), "Please Enter Valid Email Address", Toast.LENGTH_SHORT).show();
//            return false;
//
//        }
//    }
    //Validation
    private boolean isNullrec(String n)
    {

        if (n!=""&&n.length()>0)
        {
            return true;
        }
        return false;
    }

    private boolean isValidEmailId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }
}

